package com.example.new_calculator;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private TextView tvDisplay;
    private double num1 = 0;
    private double num2 = 0;
    private String operator = "";
    private boolean isNewInput = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvDisplay = findViewById(R.id.tvDisplay);
        setupButtons();
    }

    private void setupButtons() {
        // Number buttons
        int[] numberButtons = {R.id.btn0, R.id.btn1, R.id.btn2, R.id.btn3, R.id.btn4,
                R.id.btn5, R.id.btn6, R.id.btn7, R.id.btn8, R.id.btn9};

        for (int i = 0; i < numberButtons.length; i++) {
            final int number = i;
            findViewById(numberButtons[i]).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    appendNumber(String.valueOf(number));
                }
            });
        }

        // Operation buttons
        findViewById(R.id.btnAdd).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setOperator("+");
            }
        });

        findViewById(R.id.btnSubtract).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setOperator("-");
            }
        });

        findViewById(R.id.btnMultiply).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setOperator("×");
            }
        });

        findViewById(R.id.btnDivide).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setOperator("÷");
            }
        });

        // Function buttons
        findViewById(R.id.btnEquals).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculate();
            }
        });

        findViewById(R.id.btnClear).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clear();
            }
        });

        findViewById(R.id.btnDecimal).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addDecimal();
            }
        });

        findViewById(R.id.btnPercent).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculatePercent();
            }
        });

        findViewById(R.id.btnSign).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toggleSign();
            }
        });
    }

    private void appendNumber(String number) {
        if (isNewInput) {
            tvDisplay.setText(number);
            isNewInput = false;
        } else {
            String currentText = tvDisplay.getText().toString();
            if (currentText.equals("0")) {
                tvDisplay.setText(number);
            } else {
                tvDisplay.setText(currentText + number);
            }
        }
    }

    private void setOperator(String op) {
        if (!operator.isEmpty()) {
            calculate();
        }
        num1 = Double.parseDouble(tvDisplay.getText().toString());
        operator = op;
        isNewInput = true;
    }

    private void calculate() {
        if (operator.isEmpty()) return;

        num2 = Double.parseDouble(tvDisplay.getText().toString());
        double result = 0;

        switch (operator) {
            case "+":
                result = num1 + num2;
                break;
            case "-":
                result = num1 - num2;
                break;
            case "×":
                result = num1 * num2;
                break;
            case "÷":
                if (num2 != 0) {
                    result = num1 / num2;
                } else {
                    tvDisplay.setText("Error");
                    return;
                }
                break;
        }

        // Format result
        if (result == (long) result) {
            tvDisplay.setText(String.valueOf((long) result));
        } else {
            tvDisplay.setText(String.valueOf(result));
        }

        operator = "";
        isNewInput = true;
    }

    private void clear() {
        tvDisplay.setText("0");
        num1 = 0;
        num2 = 0;
        operator = "";
        isNewInput = true;
    }

    private void addDecimal() {
        String currentText = tvDisplay.getText().toString();
        if (!currentText.contains(".")) {
            tvDisplay.setText(currentText + ".");
            isNewInput = false;
        }
    }

    private void calculatePercent() {
        double number = Double.parseDouble(tvDisplay.getText().toString());
        double result = number / 100;
        tvDisplay.setText(String.valueOf(result));
        isNewInput = true;
    }

    private void toggleSign() {
        String currentText = tvDisplay.getText().toString();
        if (!currentText.equals("0")) {
            if (currentText.startsWith("-")) {
                tvDisplay.setText(currentText.substring(1));
            } else {
                tvDisplay.setText("-" + currentText);
            }
        }
    }
}